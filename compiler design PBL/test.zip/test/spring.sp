x <- 10;
y <- 5;

show -> x > 5 and y < 10;
show -> x < 5 or y < 10;
show -> not (x == 10);
